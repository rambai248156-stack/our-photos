import { firebaseConfig, CLOUD_NAME, UPLOAD_PRESET, CLOUD_LIMIT } from './config.js';
import { initializeApp } from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-app.js';
import { getAuth, onAuthStateChanged, signInAnonymously } from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-auth.js';
import { initializeFirestore, collection, doc, query, orderBy, limit, onSnapshot, addDoc, setDoc, deleteDoc, getDoc, getDocs, serverTimestamp } from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-firestore.js';
import { getStorage, ref, uploadBytesResumable, uploadString, getDownloadURL, deleteObject } from 'https://www.gstatic.com/firebasejs/13.4.0/firebase-storage.js';

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const el = (t, c, x) => { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; };
const S = (d) => `<svg viewBox="0 0 24 24">${d}</svg>`;
const IC = {
  home: S('<path d="M4 10.5 12 4l8 6.5V19a1.5 1.5 0 0 1-1.5 1.5H15v-5a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v5H5.5A1.5 1.5 0 0 1 4 19z"/>'),
  search: S('<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>'),
  insta: S('<rect x="3.2" y="3.2" width="17.6" height="17.6" rx="5.2"/><circle cx="12" cy="12" r="4.1"/><circle cx="17.3" cy="6.7" r=".9" fill="currentColor" stroke="none"/>'),
  plus: S('<path d="M12 5v14M5 12h14"/>'),
  all: S('<rect x="3.5" y="3.5" width="7" height="7" rx="2.2"/><rect x="13.5" y="3.5" width="7" height="7" rx="2.2"/><rect x="3.5" y="13.5" width="7" height="7" rx="2.2"/><rect x="13.5" y="13.5" width="7" height="7" rx="2.2"/>'),
  photo: S('<rect x="3.5" y="4" width="17" height="16" rx="4.5"/><circle cx="9" cy="9.7" r="1.7"/><path d="m4.5 17.2 4.4-4.1a1.6 1.6 0 0 1 2.2 0l2.6 2.5 1.8-1.6a1.6 1.6 0 0 1 2.1 0l2 1.8"/>'),
  video: S('<rect x="3.5" y="4.5" width="17" height="15" rx="4.5"/><path d="M10.4 9.3v5.4a.5.5 0 0 0 .8.4l4.3-2.7a.5.5 0 0 0 0-.8l-4.3-2.7a.5.5 0 0 0-.8.4z" fill="currentColor" stroke="none"/>'),
  play: S('<path d="M8 5.5v13l11-6.5z" fill="currentColor" stroke="none"/>'),
  folder: S('<path d="M3.5 7.5A2.5 2.5 0 0 1 6 5h3.2c.6 0 1.2.3 1.6.8l.8 1H18a2.5 2.5 0 0 1 2.5 2.5v7.2A2.5 2.5 0 0 1 18 19H6a2.5 2.5 0 0 1-2.5-2.5z"/>'),
  heart: S('<path d="M12 21s-7.5-4.6-9.6-9.3C.9 8.3 2.7 4.5 6.4 4.5c2.1 0 3.9 1.1 5.6 3.3 1.7-2.2 3.5-3.3 5.6-3.3 3.7 0 5.5 3.8 4 7.2C19.5 16.4 12 21 12 21z"/>'),
  chat: S('<path d="M12 3.5a8.5 8.5 0 1 1-4.1 15.9L3.5 20.5l1.3-4.2A8.5 8.5 0 0 1 12 3.5z"/>'),
  send: S('<path d="M21 3 3.5 10.1l6.9 3.2 3.2 6.9z"/><path d="M21 3 10.4 13.3"/>'),
  arrow: S('<path d="M5 12h14M13 6l6 6-6 6"/>'),
  close: S('<path d="M6 6l12 12M18 6 6 18"/>'),
  back: S('<path d="m15 5-7 7 7 7"/>'),
  download: S('<path d="M12 4v11M7.5 11 12 15.5 16.5 11M5 20h14"/>'),
  trash: S('<path d="M4.5 7h15M9.5 7V4.5h5V7M6.5 7l.8 12a1.5 1.5 0 0 0 1.5 1.4h6.4a1.5 1.5 0 0 0 1.5-1.4L17.5 7"/>'),
};
$$('[data-i]').forEach((e) => (e.innerHTML = IC[e.dataset.i]));

/* ---------- Firebase ---------- */
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = initializeFirestore(app, { experimentalAutoDetectLongPolling: true }); // keeps real-time working on every network
const storage = getStorage(app);

let me = '', authErr = null, cur = null, filter = 'all', lim = 45, growing = false, ready = false, skel = true;
let unsubFeed, unsubC, likes = new Set(), docs = [], cache = [], cacheAt = 0;
const P = new Map(), els = new Map(), grid = $('#grid');
const nameOf = (u) => 'Guest ' + String(u).replace(/[^a-z0-9]/gi, '').slice(0, 4).toUpperCase();
const toPost = (d) => { const x = d.data({ serverTimestamps: 'estimate' }); return { ...x, id: d.id }; };
const localId = () => { let i = localStorage.getItem('op-uid'); if (!i) localStorage.setItem('op-uid', (i = 'd' + [...crypto.getRandomValues(new Uint8Array(10))].map((b) => b.toString(36)).join('').slice(0, 20))); return i; };

const toast = (m) => { const t = el('div', 't', m); $('#toast').append(t); setTimeout(() => t.remove(), 4200); };
const mb = (n) => (n >= 1073741824 ? (n / 1073741824).toFixed(2) + ' GB' : (n / 1048576).toFixed(n < 10485760 ? 2 : 1) + ' MB');
const clock = (s) => { s = Math.round(s); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60); return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(s % 60).padStart(2, '0'); };
const eta = (s) => (!isFinite(s) ? '…' : s < 60 ? Math.ceil(s) + 's' : Math.ceil(s / 60) + ' min');
const setEmpty = (a, b) => { $('#empty b').textContent = a; $('#empty span').textContent = b; };

function why(e) { // plain-language reason + the exact fix
  const c = String(e?.code || ''), m = String(e?.message || e || '');
  if (c === 'permission-denied') return authErr ? 'Firebase Console → Authentication → Sign-in method → Anonymous ko Enable karo.' : 'Firestore rules block kar rahe hain — firestore.rules ko Firebase Console → Firestore → Rules me paste karke Publish karo.';
  if (c === 'storage/unauthorized') return 'Storage rules block kar rahe hain — storage.rules paste karke Publish karo.';
  if (/^storage\/(unknown|bucket-not-found|project-not-found|retry-limit)/.test(c)) return 'Firebase Storage enable nahi hai (ya net bahut slow hai).';
  if (/operation-not-allowed|admin-restricted/.test(c)) return 'Firebase Console → Authentication → Sign-in method → Anonymous ko Enable karo.';
  if (/preset/i.test(m)) return `Cloudinary me Unsigned upload preset "${UPLOAD_PRESET}" banao (Settings → Upload).`;
  if (c === 'unavailable' || /network|failed to fetch/i.test(m)) return 'Internet / server se connect nahi ho paya.';
  return m.slice(0, 160) || 'Kuch gadbad hui';
}

/* ---------- layers: every overlay owns one history entry, so Back closes it instead of leaving the app ---------- */
const stack = [];
const show = (n) => { n.hidden = false; requestAnimationFrame(() => requestAnimationFrame(() => n.classList.add('on'))); };
const hide = (n) => { n.classList.remove('on'); setTimeout(() => { if (!n.classList.contains('on')) n.hidden = true; }, 330); };
function push(node, onClose) { stack.push({ node, onClose }); history.pushState({ d: stack.length }, ''); show(node); }
const pop = () => history.back();
addEventListener('popstate', () => {
  const d = history.state?.d || 0;
  while (stack.length > d) { const l = stack.pop(); hide(l.node); l.onClose?.(); }
});
history.replaceState({ d: 0 }, '');
$$('.bd').forEach((b) => (b.onclick = pop));

/* ---------- feed (real-time) ---------- */
function card(p) {
  const c = el('button', 'card'); c.dataset.id = p.id; c.type = 'button';
  const t = el('div', 'th');
  const src = p.thumb || (p.kind === 'photo' ? p.media : '');
  if (src) {
    const i = new Image(); i.alt = ''; i.loading = 'lazy'; i.decoding = 'async'; i.draggable = false;
    i.onerror = () => { if (p.kind === 'photo' && !i.dataset.fb) { i.dataset.fb = 1; i.src = p.media; } else i.remove(); };
    i.src = src; t.append(i);
  }
  if (p.kind === 'video') { const b = el('span', 'vb'); b.innerHTML = IC.play; b.append(p.dur ? clock(p.dur) : 'Video'); t.append(b); }
  const h = el('span', 'hb'); h.innerHTML = IC.heart; t.append(h);
  c.append(t, el('div', 'ti'));
  fill(c, p); return c;
}
function fill(c, p) {
  const ti = $('.ti', c); ti.textContent = p.title || 'Untitled'; ti.classList.toggle('mu', !p.title);
  $('.hb', c).hidden = !likes.has(p.id);
}
function render() {
  if (!ready) return;
  if (skel) { grid.replaceChildren(); skel = false; }
  const list = docs.filter((p) => filter === 'all' || p.kind === filter), keep = new Set(list.map((p) => p.id));
  for (const [id, c] of els) if (!keep.has(id)) { c.remove(); els.delete(id); }
  list.forEach((p, i) => {
    P.set(p.id, p);
    let c = els.get(p.id);
    if (c) fill(c, p); else { c = card(p); els.set(p.id, c); }
    if (grid.children[i] !== c) grid.insertBefore(c, grid.children[i] || null);
  });
  $('#empty').hidden = list.length > 0;
  maybeGrow();
}
function subFeed() {
  unsubFeed?.();
  unsubFeed = onSnapshot(query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(lim)), (s) => {
    growing = false; docs = s.docs.map(toPost); ready = true;
    if (!docs.length) s.metadata?.fromCache ? setEmpty('Connecting…', 'Checking your internet') : setEmpty('Nothing here yet', 'Tap + to add a photo or video');
    render();
  }, (e) => { ready = true; skel = false; grid.replaceChildren(); setEmpty('Setup needed', why(e)); $('#empty').hidden = false; });
}
function maybeGrow() {
  if (!ready || growing || docs.length < lim) return;
  if ($('#more').getBoundingClientRect().top < innerHeight + 900) { growing = true; lim += 45; subFeed(); }
}
addEventListener('scroll', maybeGrow, { passive: true });
function paintLikes() {
  $$('.card').forEach((c) => ($('.hb', c).hidden = !likes.has(c.dataset.id)));
  if (cur) $('#vl').classList.toggle('liked', likes.has(cur.id));
}
function bind(g) { g.onclick = (e) => { const c = e.target.closest('.card'); if (c && P.get(c.dataset.id)) view(P.get(c.dataset.id)); }; }
bind(grid); bind($('#sg'));

/* ---------- full-screen viewer ---------- */
function view(p) {
  cur = p;
  const st = $('#stage'); st.replaceChildren();
  let m;
  if (p.kind === 'video') {
    m = el('video'); m.controls = true; m.playsInline = true; m.autoplay = true;
    if (p.thumb) m.poster = p.thumb;
    m.src = p.media;
    m.onerror = () => st.replaceChildren(el('p', '', "This video can't play in this browser. Use Download."));
  } else {
    m = el('img'); m.alt = p.title || ''; m.src = p.thumb || p.media;
    if (p.thumb) { const f = new Image(); f.onload = () => { if (cur?.id === p.id) m.src = p.media; }; f.src = p.media; } // quick preview, then the HD original
  }
  st.append(m);
  $('#vt').textContent = p.title || ''; $('#vt').hidden = !p.title;
  $('#vd').textContent = p.desc || ''; $('#vd').hidden = !p.desc;
  $('#vl').classList.toggle('liked', likes.has(p.id));
  $('#vdel').hidden = p.uid !== me;
  push($('#viewer'), () => { $('#stage').replaceChildren(); cur = null; });
}
$('#vx').onclick = pop;
$('#vl').onclick = () => {
  const p = cur; if (!p) return;
  const r = doc(db, 'users', me, 'likes', p.id), on = !likes.has(p.id);
  on ? likes.add(p.id) : likes.delete(p.id); paintLikes();
  (on ? setDoc(r, { at: serverTimestamp() }) : deleteDoc(r)).catch((e) => { on ? likes.delete(p.id) : likes.add(p.id); paintLikes(); toast(why(e)); });
};
$('#vs').onclick = async () => {
  const u = `${location.origin}${location.pathname}?p=${cur.id}`;
  try {
    if (navigator.share) await navigator.share({ title: cur.title || 'Our Photos', url: u });
    else { await navigator.clipboard.writeText(u); toast('Link copied'); }
  } catch {}
};
const link = (href, dl) => { const a = document.createElement('a'); a.href = href; a.rel = 'noopener'; if (dl) a.download = dl; document.body.append(a); a.click(); a.remove(); };
let dlWait = false;
$('#vdn').onclick = async () => { // one tap = one download of the original file, with a brand-new file name every time
  const p = cur; if (!p || dlWait) return;
  dlWait = true; setTimeout(() => (dlWait = false), 1500);
  const base = (p.title || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30) || p.kind;
  const name = `${base}-${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`;
  toast('Download started');
  if (p.store === 'cld' && p.media.includes('/upload/')) return link(p.media.replace('/upload/', `/upload/fl_attachment:${name}/`));
  try {
    const r = await fetch(p.media); if (!r.ok) throw 0;
    const u = URL.createObjectURL(await r.blob());
    link(u, `${name}.${(/\.([a-z0-9]{2,5})(\?|$)/i.exec(p.path || '')?.[1] || (p.kind === 'video' ? 'mp4' : 'jpg'))}`);
    setTimeout(() => URL.revokeObjectURL(u), 60000);
  } catch { link(p.media); }
};
$('#vdel').onclick = async () => {
  const p = cur; if (!p || !confirm('Delete this post for everyone?')) return;
  try {
    await deleteDoc(doc(db, 'posts', p.id));
    if (p.store === 'fb') for (const x of [p.path, p.tpath]) if (x) deleteObject(ref(storage, x)).catch(() => {});
    toast('Deleted'); history.go(-stack.length);
  } catch (e) { toast(why(e)); }
};

/* comments (real-time while the sheet is open) */
function addC(c) {
  const l = $('#cl'); if (l.querySelector(`[data-id="${c.id}"]`)) return;
  const d = el('div', 'cm'); d.dataset.id = c.id;
  d.append(el('b', '', (c.name || nameOf(c.uid)) + (c.uid === me ? ' (you)' : '')), el('span', '', c.text));
  l.append(d); l.scrollTop = l.scrollHeight;
}
$('#vc').onclick = () => {
  const p = cur; $('#cl').replaceChildren();
  push($('#cmts'), () => { unsubC?.(); unsubC = null; });
  unsubC = onSnapshot(query(collection(db, 'posts', p.id, 'comments'), orderBy('createdAt', 'asc'), limit(200)),
    (s) => s.docs.forEach((d) => addC({ ...d.data({ serverTimestamps: 'estimate' }), id: d.id })), (e) => toast(why(e)));
};
$('#cf').onsubmit = (e) => {
  e.preventDefault();
  const v = $('#ci').value.trim(); if (!v || !cur) return;
  $('#ci').value = '';
  addDoc(collection(db, 'posts', cur.id, 'comments'), { uid: me, name: nameOf(me), text: v.slice(0, 400), createdAt: serverTimestamp() }).catch((x) => toast(why(x)));
};

/* ---------- nav, filter, search ---------- */
function setFilter(f) {
  filter = f;
  $('#nfi').innerHTML = IC[f]; $('#nfl').textContent = { all: 'All', photo: 'Photos', video: 'Videos' }[f];
  $$('#flt [data-f]').forEach((b) => b.classList.toggle('on', b.dataset.f === f));
  $('#nf').classList.toggle('on', f !== 'all'); $('#nh').classList.toggle('on', f === 'all');
  render();
}
$('#nf').onclick = () => push($('#flt'));
$$('#flt [data-f]').forEach((b) => (b.onclick = () => { pop(); setFilter(b.dataset.f); }));
$('#nh').onclick = () => { if (stack.length) history.go(-stack.length); if (filter !== 'all') setFilter('all'); scrollTo({ top: 0, behavior: 'smooth' }); };

let st;
async function openSearch() {
  $('#si').value = ''; $('#sg').replaceChildren(); push($('#search')); $('#si').focus();
  if (Date.now() - cacheAt > 60000) {
    try { cache = (await getDocs(query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(300)))).docs.map(toPost); cacheAt = Date.now(); runSearch(); }
    catch (e) { toast(why(e)); }
  }
}
function runSearch() {
  const terms = $('#si').value.toLowerCase().split(/\s+/).filter(Boolean), g = $('#sg'); g.replaceChildren();
  if (!terms.length) return;
  const seen = new Set();
  for (const p of [...docs, ...cache]) {
    if (seen.has(p.id)) continue; seen.add(p.id);
    const t = (p.title || '').toLowerCase();
    if (terms.every((x) => t.includes(x))) { P.set(p.id, p); g.append(card(p)); }
  }
}
$('#s1').onclick = $('#ns').onclick = openSearch;
$('#sx').onclick = pop;
$('#sf').onsubmit = (e) => { e.preventDefault(); $('#si').blur(); };
$('#si').oninput = () => { clearTimeout(st); st = setTimeout(runSearch, 120); };

/* ---------- Instagram: launches the app itself, so it resumes on the screen you left it ---------- */
$('#ig').onclick = () => {
  const web = 'https://www.instagram.com/', ua = navigator.userAgent;
  const t = setTimeout(() => { if (!document.hidden) window.open(web, '_blank', 'noopener'); }, 1500);
  addEventListener('pagehide', () => clearTimeout(t), { once: true });
  document.addEventListener('visibilitychange', () => clearTimeout(t), { once: true });
  if (/Android/i.test(ua)) location.href = `intent://instagram.com/#Intent;package=com.instagram.android;scheme=https;S.browser_fallback_url=${encodeURIComponent(web)};end`;
  else if (/iPhone|iPad|iPod/i.test(ua)) location.href = 'instagram://app';
  else { clearTimeout(t); window.open(web, '_blank', 'noopener'); }
};

/* ---------- upload ---------- */
let pending = null;
const MAX_BYTES = 5 * 1073741824;
const MIME = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', avif: 'image/avif', mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', mkv: 'video/x-matroska', '3gp': 'video/3gpp' };
$('#fab').onclick = () => push($('#add'));
$$('[data-pick]').forEach((b) => (b.onclick = () => { const i = $('#' + b.dataset.pick); i.value = ''; i.click(); pop(); }));
const kindOf = (f) => (/^video\//.test(f.type) || /\.(mp4|m4v|mov|webm|mkv|3gp)$/i.test(f.name) ? 'video' : /^image\//.test(f.type) || /\.(jpe?g|png|gif|webp|avif)$/i.test(f.name) ? 'photo' : null);
for (const [id, want] of [['fp', 'photo'], ['fv', 'video'], ['ff', null]]) {
  $('#' + id).onchange = (e) => {
    const f = e.target.files[0]; if (!f) return;
    const k = kindOf(f);
    if (!k || (want && k !== want)) return toast(want ? `Please choose a ${want}` : 'Only photos and videos');
    if (f.size > MAX_BYTES) return toast('Max size is 5 GB');
    pending = { f, k };
    $('#ttl').value = ''; $('#dsc').value = '';
    const u = URL.createObjectURL(f), m = k === 'video' ? el('video') : el('img');
    if (k === 'video') { m.muted = true; m.loop = true; m.autoplay = true; m.playsInline = true; }
    m.src = u; $('#prev').replaceChildren(m);
    push($('#compose'), () => { URL.revokeObjectURL(u); $('#prev').replaceChildren(); });
  };
}
$$('#compose input,#compose textarea').forEach((i) => (i.onfocus = () => setTimeout(() => i.scrollIntoView({ block: 'center', behavior: 'smooth' }), 300)));
$('#go').onclick = () => {
  const { f, k } = pending, title = $('#ttl').value.trim(), desc = $('#dsc').value.trim();
  if (window.Notification && Notification.permission === 'default') Notification.requestPermission().catch(() => {});
  pop(); send(f, k, title, desc);
};

function thumbOf(src, w, h) {
  const k = Math.min(1, 640 / Math.max(w, h)), c = document.createElement('canvas');
  c.width = Math.round(w * k); c.height = Math.round(h * k);
  const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(src, 0, 0, c.width, c.height);
  const d = c.toDataURL('image/jpeg', 0.8); return d.length < 500000 ? d : '';
}
async function probe(f, k) { // size + small preview only; the file itself is uploaded untouched
  const o = { w: 0, h: 0, dur: 0, thumb: '' };
  try {
    if (k === 'photo') { const b = await createImageBitmap(f); o.w = b.width; o.h = b.height; o.thumb = thumbOf(b, b.width, b.height); b.close?.(); }
    else {
      const v = document.createElement('video'), u = URL.createObjectURL(f);
      v.muted = true; v.playsInline = true; v.preload = 'auto'; v.src = u;
      await new Promise((ok, no) => { v.onloadeddata = ok; v.onerror = no; setTimeout(no, 8000); });
      o.w = v.videoWidth; o.h = v.videoHeight; o.dur = isFinite(v.duration) ? v.duration : 0;
      v.currentTime = Math.min(1, (v.duration || 1) / 10);
      await new Promise((ok) => { v.onseeked = ok; setTimeout(ok, 3000); });
      o.thumb = thumbOf(v, v.videoWidth, v.videoHeight); URL.revokeObjectURL(u);
    }
  } catch {}
  return o;
}
const cldThumb = (u, k) => !u.includes('/upload/') ? '' : k === 'video'
  ? u.replace('/upload/', '/upload/so_0,c_fill,w_480,h_480,g_auto,q_auto/').replace(/\.[a-z0-9]+$/i, '.jpg')
  : u.replace('/upload/', '/upload/c_fill,w_480,h_480,g_auto,q_auto,f_auto/');

function cloudUpload(f, k, prog) { // straight from the browser to Cloudinary, original bytes, real progress
  return new Promise((ok, no) => {
    const x = new XMLHttpRequest();
    x.open('POST', `https://api.cloudinary.com/v1_1/${CLOUD_NAME}/${k === 'video' ? 'video' : 'image'}/upload`);
    x.upload.onprogress = (e) => e.lengthComputable && prog(e.loaded, e.total);
    x.onload = () => {
      let j = {}; try { j = JSON.parse(x.responseText); } catch {}
      x.status < 300 && j.secure_url ? ok({ store: 'cld', url: j.secure_url, thumb: cldThumb(j.secure_url, k), path: j.public_id || '', tpath: '', w: j.width || 0, h: j.height || 0, dur: j.duration || 0 })
        : no(new Error(j.error?.message || `Cloudinary error ${x.status}`));
    };
    x.onerror = x.ontimeout = () => no(new Error('Network error'));
    const fd = new FormData(); fd.append('upload_preset', UPLOAD_PRESET); fd.append('file', f);
    x.send(fd);
  });
}
async function fbUpload(f, k, prog) { // Firebase Storage: resumable, no size limit — used for files Cloudinary's free plan can't take
  const meta = await probe(f, k);
  const ext = (/\.([a-z0-9]{1,5})$/i.exec(f.name)?.[1] || (k === 'video' ? 'mp4' : 'jpg')).toLowerCase();
  const id = doc(collection(db, 'posts')).id, path = `media/${me}/${id}.${ext}`;
  const task = uploadBytesResumable(ref(storage, path), f, { contentType: f.type || MIME[ext] || (k === 'video' ? 'video/mp4' : 'image/jpeg') });
  await new Promise((ok, no) => task.on('state_changed', (s) => prog(s.bytesTransferred, s.totalBytes), no, ok));
  const url = await getDownloadURL(task.snapshot.ref);
  let thumb = '', tpath = '';
  if (meta.thumb) { try { tpath = `media/${me}/${id}_t.jpg`; await uploadString(ref(storage, tpath), meta.thumb, 'data_url'); thumb = await getDownloadURL(ref(storage, tpath)); } catch { tpath = ''; } }
  return { store: 'fb', url, thumb, path, tpath, w: meta.w, h: meta.h, dur: meta.dur };
}

let busyUp = 0, lock;
addEventListener('beforeunload', (e) => { if (busyUp) { e.preventDefault(); e.returnValue = ''; } });

async function send(f, k, title, desc) {
  const n = el('div', 'up');
  n.innerHTML = '<div class="r"><div class="nm"></div><b class="pc">0%</b></div><div class="bar"><i></i></div><div class="r s"><span class="a">Preparing…</span><span class="b"></span></div>';
  $('.nm', n).textContent = title || f.name; $('#ups').prepend(n);
  const set = (a, b) => { $('.a', n).textContent = a; $('.b', n).textContent = b || ''; };
  let t0 = performance.now();
  const prog = (l, t) => {
    const sp = l / ((performance.now() - t0) / 1000 || 1);
    $('.pc', n).textContent = Math.floor((l / t) * 100) + '%'; $('.bar i', n).style.width = (l / t) * 100 + '%';
    set(`${mb(l)} of ${mb(t)}`, `${mb(sp)}/s · ${eta((t - l) / sp)} left`);
  };
  busyUp++;
  try { lock = await navigator.wakeLock?.request('screen'); } catch {}
  try {
    let r = null, cErr = null;
    const big = f.size > CLOUD_LIMIT[k];
    if (CLOUD_NAME && UPLOAD_PRESET && !big) {
      try { set('Uploading…'); r = await cloudUpload(f, k, prog); } catch (e) { cErr = e; console.warn('Cloudinary failed:', e); }
    }
    if (!r) {
      set(big ? 'Big file → Firebase Storage' : 'Switching to Firebase Storage…'); t0 = performance.now();
      $('.pc', n).textContent = '0%'; $('.bar i', n).style.width = '0%';
      try { r = await fbUpload(f, k, prog); } catch (e) { throw cErr ? new Error(`${why(cErr)}  |  ${why(e)}`) : e; }
    }
    set('Saving…');
    await addDoc(collection(db, 'posts'), {
      uid: me, kind: k, title, desc, media: r.url, thumb: r.thumb || '', store: r.store, path: r.path || '', tpath: r.tpath || '',
      w: r.w || 0, h: r.h || 0, dur: r.dur || 0, size: f.size, name: f.name.slice(0, 120), createdAt: serverTimestamp(),
    });
    $('.pc', n).textContent = '100%'; $('.bar i', n).style.width = '100%'; set('Uploaded — original HD, live for everyone', 'Done');
    setTimeout(() => n.remove(), 4000);
    if (document.hidden && window.Notification && Notification.permission === 'granted') { try { new Notification('Upload complete', { body: title || f.name }); } catch {} }
  } catch (e) {
    console.error(e); n.classList.add('err'); $('.pc', n).textContent = '!';
    const m = e.message?.includes('|') ? e.message : why(e); set(m, ''); toast(m); setTimeout(() => n.remove(), 12000);
  } finally { if (!--busyUp) { lock?.release?.().catch(() => {}); lock = null; } }
}

/* ---------- boot ---------- */
if (window.visualViewport) {
  const u = () => document.documentElement.style.setProperty('--kb', Math.max(0, innerHeight - visualViewport.height - visualViewport.offsetTop) + 'px');
  visualViewport.addEventListener('resize', u); visualViewport.addEventListener('scroll', u);
}
if (matchMedia('(pointer:coarse)').matches && !matchMedia('(display-mode:fullscreen),(display-mode:standalone)').matches && document.documentElement.requestFullscreen) {
  addEventListener('pointerup', () => document.documentElement.requestFullscreen({ navigationUI: 'hide' }).catch(() => {}), { once: true, capture: true });
}
grid.replaceChildren(...Array.from({ length: 9 }, () => el('div', 'sk')));
(async () => {
  try {
    let user = await new Promise((ok) => { const u = onAuthStateChanged(auth, (x) => { u(); ok(x); }); });
    if (!user) { try { user = (await signInAnonymously(auth)).user; } catch (e) { authErr = e; console.warn('Anonymous sign-in failed:', e); } }
    me = user?.uid || localId();
    onSnapshot(collection(db, 'users', me, 'likes'), (s) => { likes = new Set(s.docs.map((d) => d.id)); paintLikes(); }, () => {});
    subFeed();
    const p = new URLSearchParams(location.search).get('p');
    if (p) {
      history.replaceState({ d: 0 }, '', location.pathname);
      try { const d = await getDoc(doc(db, 'posts', p)); if (d.exists()) { const x = toPost(d); P.set(x.id, x); view(x); } } catch {}
    }
  } catch (e) { grid.replaceChildren(); setEmpty('Cannot start', why(e)); $('#empty').hidden = false; }
})();
